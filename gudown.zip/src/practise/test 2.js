import React from "react"
 function Test2 Conditional (props){
       return(
         <div>           
               <button onClick={()=>props.handleclick(props.product.plus,props.product.id)}>{props.product.plus}</button>
         </div>
         )
       }
export default Test2