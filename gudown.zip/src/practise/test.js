import React from "react";
class Test extends React.Component {
  constructor() {
    super()
    this.state = {
      firstName:"",
      lastName:"",
      age:"",
      display:false,
      count:0
    }
    this.submitChange=this.submitChange.bind(this)
    this.handleChange=this.handleChange.bind(this)
  }
  handleChange(event){
      const{name,value}=event.target
      this.setState({
            [name]:value
      })
}
   submitChange(){
        this.setState({display:true,})                 
   }


  render() {
    return (
          <div>
      <form>
          <input 
          type="text" 
          placeholder="First Name"
          name="firstName"
          onChange={this.handleChange}
          />
          <br/>
          <br/>

          <input 
          type="text" 
          placeholder="last Name"
          name="lastName"
          onChange={this.handleChange}
          />
          <br/>
          <br/>

          <input 
          type="text" 
          placeholder="Age"
          name="age"
          onChange={this.handleChange}
          />
          <br/>
          <br/>
  </form>
  <button onClick={this.submitChange}>submit</button>
          <br/>
          {this.state.display?
      <div><p>First Name:{this.state.firstName}</p>      
      <p>last Name:{this.state.lastName}</p>
      <p>Age:{this.state.age}</p>
      </div>:
      <div><p>First Name:{null}</p>      
      <p>last Name:{null}</p>
      <p>Age:{null}</p>
      </div>
  }
    </div>
    

  
     
 
    )
  }
}
export default Test;
